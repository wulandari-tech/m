const midtransClient = require('midtrans-client');

const snap = new midtransClient.Snap({
    isProduction: process.env.MIDTRANS_IS_PRODUCTION === 'true',
    serverKey: "Mid-server-zvgGUiY7SS-HS_qhWLkqZQuL",
    clientKey: "Mid-client-IoIOg2RqJNZgKpY6"
});

module.exports = snap;