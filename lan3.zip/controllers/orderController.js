const Order = require('../models/order');
const SourceCode = require('../models/sourceCode');
const User =require('../models/user');
const Transaction = require('../models/transaction');
const midtransClient = require('midtrans-client');
const qrisHelper = require('../utils/qrisHelper');
const { v4: uuidv4 } = require('uuid');

const MIDTRANS_SERVER_KEY_ORDER = "Mid-server-zvgGUiY7SS-HS_qhWLkqZQuL"; 
const MIDTRANS_CLIENT_KEY_ORDER = "Mid-client-IoIOg2RqJNZgKpY6"; 
const MIDTRANS_IS_PRODUCTION_ORDER = true;
const snapOrder = new midtransClient.Snap({
    isProduction: MIDTRANS_IS_PRODUCTION_ORDER,
    serverKey: MIDTRANS_SERVER_KEY_ORDER,
    clientKey: MIDTRANS_CLIENT_KEY_ORDER
});

async function completeOrderAndTransaction(order, transaction, paymentDetails = "") {
    order.paymentStatus = 'completed';
    if (order.sourceCode && typeof order.sourceCode === 'object' && order.sourceCode.filePath && order.orderType === 'buy') {
        order.downloadLink = `/${order.sourceCode.filePath.replace(/\\/g, '/')}`;
    } else if (typeof order.sourceCode === 'string' && order.orderType === 'buy') {
        const sc = await SourceCode.findById(order.sourceCode).select('filePath');
        if (sc && sc.filePath) {
            order.downloadLink = `/${sc.filePath.replace(/\\/g, '/')}`;
        }
    }
    await order.save();

    transaction.status = 'success';
    transaction.description = transaction.description.replace(/\(Pending\)/gi, `(Success${paymentDetails})`);
    await transaction.save();
}

async function failOrderAndTransaction(order, transaction, reason = "") {
    if (order && order.paymentStatus !== 'completed') {
        order.paymentStatus = 'failed';
        await order.save();
    }
    
    if (transaction && transaction.status !== 'success') {
        transaction.status = 'failed';
        transaction.description = transaction.description.replace(/\(Pending\)/gi, `(Failed${reason ? ' - ' + reason : ''})`);
        await transaction.save();
    }
}

exports.createOrder = async (req, res) => {
    const { scId, orderType, payment_method, rentalOptionIndex } = req.body;
    const userId = req.user._id;
    let newOrder, pendingScTransaction;

    try {
        const sc = await SourceCode.findById(scId).populate('seller', 'qrisBaseCode name email _id qrisMerchantId qrisApiKey');
        if (!sc || sc.status !== 'approved') {
            req.flash('error_msg', 'Source code tidak valid atau tidak tersedia.');
            return res.redirect(scId ? `/sc/${scId}` : '/sc-list');
        }

        if (orderType === 'buy') {
            const existingBuyOrder = await Order.findOne({ user: userId, sourceCode: scId, orderType: 'buy', paymentStatus: 'completed' });
            if (existingBuyOrder) {
                req.flash('info_msg', 'Anda sudah membeli source code ini.');
                return res.redirect(`/sc/${scId}`);
            }
        }

        let amount;
        let orderDetails = {
            user: userId,
            sourceCode: scId,
            scTitleAtPurchase: sc.title,
            orderType,
            paymentMethod: payment_method,
            paymentStatus: 'pending'
        };
        let itemDisplayName = `Pembelian SC: ${sc.title}`;

        if (orderType === 'buy') {
            if (sc.is_for_rent_only || !sc.price_buy) {
                req.flash('error_msg', 'SC ini tidak tersedia untuk dibeli.');
                return res.redirect(`/sc/${scId}`);
            }
            amount = sc.price_buy;
        } else if (orderType === 'rent') {
            if (!sc.rental_options || sc.rental_options.length === 0) {
                req.flash('error_msg', 'SC ini tidak tersedia untuk disewa.');
                return res.redirect(`/sc/${scId}`);
            }
            const optionIdx = parseInt(rentalOptionIndex);
            if (isNaN(optionIdx) || optionIdx < 0 || optionIdx >= sc.rental_options.length) {
                req.flash('error_msg', 'Opsi sewa tidak valid.');
                return res.redirect(`/sc/${scId}`);
            }
            const selectedOption = sc.rental_options[optionIdx];
            amount = selectedOption.price;
            orderDetails.rentalOption = { duration: selectedOption.duration, price: selectedOption.price };
            let endDate = new Date();
            const [num, unit] = selectedOption.duration.split(' ');
            const numVal = parseInt(num);
            if (unit.toLowerCase().includes('minggu')) endDate.setDate(endDate.getDate() + (numVal * 7));
            else if (unit.toLowerCase().includes('bulan')) endDate.setMonth(endDate.getMonth() + numVal);
            else if (unit.toLowerCase().includes('tahun')) endDate.setFullYear(endDate.getFullYear() + numVal);
            orderDetails.rentalEndDate = endDate;
            itemDisplayName = `Sewa SC: ${sc.title} (${selectedOption.duration})`;
        } else {
            req.flash('error_msg', 'Tipe order tidak valid.');
            return res.redirect(`/sc/${scId}`);
        }
        orderDetails.amount = amount;

        const orderTransactionId = `ORD-${uuidv4().slice(0, 12).toUpperCase()}`;
        orderDetails.midtransOrderId = orderTransactionId;

        newOrder = new Order(orderDetails);
        await newOrder.save();

        pendingScTransaction = new Transaction({
            user: userId,
            type: orderType === 'buy' ? 'purchase_sc' : 'rent_sc',
            amount: -amount,
            description: `${itemDisplayName} (Pending) - ${payment_method}`,
            status: 'pending',
            paymentMethod: payment_method,
            midtransOrderId: orderTransactionId,
            order: newOrder._id,
            sourceCode: scId
        });
        await pendingScTransaction.save();

        if (payment_method === 'saldo') {
            if (req.user.balance < amount) {
                await failOrderAndTransaction(newOrder, pendingScTransaction, 'Saldo Tidak Cukup');
                req.flash('error_msg', 'Saldo Anda tidak mencukupi untuk transaksi ini.');
                return res.redirect(`/sc/${scId}`);
            }
            await User.findByIdAndUpdate(userId, { $inc: { balance: -amount } });
            await completeOrderAndTransaction(newOrder, pendingScTransaction);
            req.flash('success_msg', `${itemDisplayName} berhasil dibayar dengan saldo.`);
            return res.redirect(`/dashboard/orders`);

        } else if (payment_method === 'midtrans') {
            const parameter = {
                transaction_details: { order_id: orderTransactionId, gross_amount: amount },
                customer_details: { first_name: req.user.name, email: req.user.email },
                item_details: [{ id: scId.toString(), price: amount, quantity: 1, name: itemDisplayName }],
                callbacks: { finish: `${req.protocol}://${req.get('host')}/api/orders/status?order_id=${orderTransactionId}` }
            };
            const snapToken = await snapOrder.createTransactionToken(parameter);

            res.locals.midtransClientKey = MIDTRANS_CLIENT_KEY_ORDER;
            res.locals.midtransIsProduction = MIDTRANS_IS_PRODUCTION_ORDER;
            
            return res.render('balance/process_deposit', {
                titlePage: 'Proses Pembayaran SC',
                snapToken,
            });

        } else if (payment_method === 'qris_orkut') {
            if (!sc.seller || !sc.seller.qrisBaseCode) {
                await failOrderAndTransaction(newOrder, pendingScTransaction, 'Seller QRIS Not Configured');
                req.flash('error_msg', 'Metode pembayaran QRIS tidak tersedia untuk seller ini.');
                return res.redirect(`/sc/${scId}`);
            }
            const qrisData = await qrisHelper.createDynamicQRIS(amount, sc.seller.qrisBaseCode);
            newOrder.midtransOrderId = qrisData.transactionId;
            newOrder.qrisData = {
                qrImageUrl: qrisData.qrImageUrl,
                qrString: qrisData.qrString,
                transactionId: qrisData.transactionId,
                sellerQrisUsed: true
            };
            await newOrder.save();

            pendingScTransaction.midtransOrderId = qrisData.transactionId;
            pendingScTransaction.description = pendingScTransaction.description.replace(orderTransactionId, qrisData.transactionId);
            await pendingScTransaction.save();

            let checkStatusUrl = null;
            if (sc.seller.qrisMerchantId && sc.seller.qrisApiKey) {
                checkStatusUrl = `/api/orders/qris/check-status`;
            }
            return res.render('payment/qris_display', {
                titlePage: 'Bayar Pesanan dengan QRIS',
                qrisData,
                transactionType: 'order',
                scId: scId.toString(),
                orderId: newOrder._id.toString(),
                seller: { name: sc.seller.name, email: sc.seller.email },
                checkStatusUrl: checkStatusUrl
            });
        } else {
            await failOrderAndTransaction(newOrder, pendingScTransaction, 'Invalid Payment Method');
            req.flash('error_msg', 'Metode pembayaran tidak valid.');
            return res.redirect(`/sc/${scId}`);
        }

    } catch (error) {
        if (newOrder && pendingScTransaction && newOrder.paymentStatus === 'pending') {
            await failOrderAndTransaction(newOrder, pendingScTransaction, 'System Error during creation');
        } else if (newOrder && newOrder.paymentStatus === 'pending') {
             newOrder.paymentStatus = 'failed'; await newOrder.save().catch(e=>console.error(e));
        } else if (pendingScTransaction && pendingScTransaction.status === 'pending') {
             pendingScTransaction.status = 'failed'; await pendingScTransaction.save().catch(e=>console.error(e));
        }
        req.flash('error_msg', `Gagal membuat pesanan: ${error.message}`);
        return res.redirect(scId ? `/sc/${scId}` : '/sc-list');
    }
};

exports.getOrderStatusPage = async (req, res) => {
    const { order_id, status_code, transaction_status } = req.query;
    let alertType = 'info';
    let message = 'Memproses status pesanan Anda...';

    if (order_id === 'CLOSED') {
        alertType = 'warning';
        message = 'Anda menutup jendela pembayaran sebelum transaksi selesai.';
        return res.render('user/order_status', { titlePage: 'Status Pesanan', alertType, message, order_id });
    }
    if (!order_id) {
        req.flash('error_msg', 'ID Pesanan tidak ditemukan untuk status.');
        return res.redirect('/dashboard/orders');
    }

    try {
        const order = await Order.findOne({ midtransOrderId: order_id, user: req.user._id }).populate({path: 'sourceCode', select: 'filePath seller'});
        const transaction = await Transaction.findOne({ midtransOrderId: order_id, user: req.user._id });

        if (!order || !transaction) {
            message = `Pesanan/Transaksi dengan ID ${order_id} tidak ditemukan.`;
            alertType = 'danger';
        } else if (order.paymentStatus === 'completed') {
            message = `Pesanan untuk ID ${order_id} sudah berhasil sebelumnya.`;
            alertType = 'success';
        } else if (transaction_status) {
            if (transaction_status === 'capture' || transaction_status === 'settlement' || (transaction_status === 'success' && status_code === '200')) {
                if (order.paymentStatus !== 'completed') {
                    await completeOrderAndTransaction(order, transaction);
                    message = `Pembayaran untuk pesanan ID ${order_id} berhasil!`;
                    alertType = 'success';
                }
            } else if (transaction_status === 'pending') {
                message = `Pembayaran untuk pesanan ID ${order_id} sedang diproses (pending). Harap tunggu konfirmasi.`;
                alertType = 'warning';
            } else if (['expire', 'cancel', 'deny'].includes(transaction_status) || (transaction_status === 'error' && status_code !== '200')) {
                await failOrderAndTransaction(order, transaction, transaction_status);
                message = `Pembayaran untuk pesanan ID ${order_id} gagal atau dibatalkan. Status: ${transaction_status}.`;
                alertType = 'danger';
            } else {
                message = `Status pembayaran untuk pesanan ID ${order_id} adalah ${transaction_status}.`;
                alertType = 'info';
            }
        } else {
            message = `Status untuk pesanan ID ${order_id} adalah ${order.paymentStatus}.`;
            if (order.paymentStatus === 'completed') alertType = 'success';
            else if (order.paymentStatus === 'pending') alertType = 'warning';
            else alertType = 'danger';
        }
        return res.render('user/order_status', { titlePage: 'Status Pesanan', alertType, message, order_id });
    } catch (error) {
        req.flash('error_msg', 'Terjadi kesalahan saat memeriksa status pesanan.');
        return res.redirect('/dashboard/orders');
    }
};

exports.handleMidtransOrderNotification = async (req, res) => {
    try {
        const notificationJson = req.body;
        const statusResponse = await snapOrder.transaction.notification(notificationJson);
        
        let orderId = statusResponse.order_id;
        let transactionStatus = statusResponse.transaction_status;
        let fraudStatus = statusResponse.fraud_status;
        let paymentType = statusResponse.payment_type || 'Midtrans';

        const order = await Order.findOne({ midtransOrderId: orderId }).populate({path: 'sourceCode', select: 'filePath seller'});
        const transaction = await Transaction.findOne({ midtransOrderId: orderId });

        if (!order || !transaction) {
            return res.status(404).send('Order/Transaction not found');
        }
        
        if (order.paymentStatus === 'pending') {
            if (transactionStatus == 'capture' || transactionStatus == 'settlement') {
                if (fraudStatus == 'accept') {
                    await completeOrderAndTransaction(order, transaction, ` via ${paymentType}`);
                } else if (fraudStatus == 'challenge') {
                    transaction.description = transaction.description.replace(/\(Pending\)/gi, `(Challenged by Fraud System via ${paymentType})`);
                    await transaction.save();
                }
            } else if (['cancel', 'deny', 'expire'].includes(transactionStatus)) {
                await failOrderAndTransaction(order, transaction, `${transactionStatus} via ${paymentType}`);
            } else if (transactionStatus == 'pending') {
                 transaction.description = transaction.description.replace(/\(Pending\)/gi, `(Still Pending via ${paymentType})`);
                 await transaction.save();
            }
        }
        return res.status(200).send('Notification processed.');
    } catch (error) {
        return res.status(500).send('Error processing order notification');
    }
};


exports.checkQrisOrderStatus = async (req, res) => {
    const { transactionId, orderId } = req.body;
    
    if (!orderId || !transactionId) {
        req.flash('error_msg', 'ID Pesanan atau ID Transaksi QRIS tidak valid.');
        return res.redirect('back');
    }

    try {
        const order = await Order.findById(orderId).populate({path: 'sourceCode', select: 'filePath seller'});
        if (!order || order.user.toString() !== req.user._id.toString()) {
            req.flash('error_msg', 'Pesanan tidak ditemukan atau bukan milik Anda.');
            return res.redirect('/dashboard/orders');
        }
        if (order.paymentStatus === 'completed') {
            req.flash('success_msg', 'Pesanan ini sudah berhasil dibayar sebelumnya.');
            return res.redirect('/dashboard/orders');
        }
        if (!order.qrisData || order.qrisData.transactionId !== transactionId) {
            req.flash('error_msg', 'Data QRIS untuk pesanan ini tidak cocok.');
            return res.redirect('/dashboard/orders');
        }

        const seller = await User.findById(order.sourceCode.seller);
        if (!seller || !seller.qrisMerchantId || !seller.qrisApiKey) {
            req.flash('info_msg', 'Pengecekan status otomatis QRIS tidak tersedia untuk seller ini. Seller akan memverifikasi manual.');
            return res.redirect('/dashboard/orders');
        }

        const statusResult = await qrisHelper.checkQRISPaymentStatus(seller.qrisMerchantId, seller.qrisApiKey);
        if (statusResult.success && Array.isArray(statusResult.data)) {
            const paidTx = statusResult.data.find(mutasi => 
                parseInt(mutasi.amount) === order.amount &&
                new Date(mutasi.date) > new Date(order.createdAt.getTime() - 10 * 60 * 1000) &&
                new Date(mutasi.date) < new Date(Date.now() + 5 * 60 * 1000)
            );

            if (paidTx) {
                const transaction = await Transaction.findOne({ order: order._id, midtransOrderId: transactionId });
                if (transaction && transaction.status !== 'success') {
                    await completeOrderAndTransaction(order, transaction, ` via QRIS Seller (Okeconnect - ${paidTx.brand_name || 'Unknown'})`);
                    req.flash('success_msg', 'Pembayaran QRIS berhasil dikonfirmasi via Okeconnect!');
                } else if (!transaction) {
                    req.flash('error_msg', 'Transaksi terkait tidak ditemukan untuk pembaruan status QRIS.');
                }
            } else {
                req.flash('info_msg', 'Status pembayaran QRIS belum terkonfirmasi di Okeconnect. Mohon tunggu atau seller akan verifikasi.');
            }
        } else {
            req.flash('error_msg', `Gagal memeriksa status ke Okeconnect: ${statusResult.message || 'Data tidak diterima.'}`);
        }
        return res.redirect('/dashboard/orders');
    } catch (error) {
        req.flash('error_msg', 'Terjadi kesalahan saat memeriksa status pesanan QRIS.');
        return res.redirect('/dashboard/orders');
    }
};