const User = require('../models/user');
const Transaction = require('../models/transaction');
const midtransClient = require('midtrans-client');
const qrisHelper = require('../utils/qrisHelper');
const { v4: uuidv4 } = require('uuid');
const MIDTRANS_SERVER_KEY_BALANCE = "Mid-server-zvgGUiY7SS-HS_qhWLkqZQuL";
const MIDTRANS_CLIENT_KEY_BALANCE = "Mid-client-IoIOg2RqJNZgKpY6";
const MIDTRANS_IS_PRODUCTION_BALANCE = true;
const snapBalance = new midtransClient.Snap({
    isProduction: MIDTRANS_IS_PRODUCTION_BALANCE,
    serverKey: MIDTRANS_SERVER_KEY_BALANCE,
    clientKey: MIDTRANS_CLIENT_KEY_BALANCE
});

exports.getDepositForm = async (req, res) => {
    try {
        const recentTransactions = await Transaction.find({ user: req.user._id, type: 'deposit' })
            .sort({ createdAt: -1 })
            .limit(5);
        res.render('balance/deposit_form', {
            titlePage: 'Deposit Saldo',
            user: req.user,
            recentTransactions,
            breadcrumbs: [{ name: 'Dashboard', url: '/dashboard' }, { name: 'Deposit Saldo', active: true }]
        });
    } catch (error) {
        req.flash('error_msg', 'Gagal memuat form deposit.');
        res.redirect('/dashboard');
    }
};

exports.processDepositRequest = async (req, res) => {
    const { amount, payment_method } = req.body;
    const userId = req.user._id;
    const userEmail = req.user.email;
    const userName = req.user.name;

    const depositAmount = parseInt(amount);
    if (isNaN(depositAmount) || depositAmount < 10000) {
        req.flash('error_msg', 'Jumlah deposit minimal Rp 10.000.');
        return res.redirect('/dashboard/deposit');
    }

    const transactionId = `DEP-${uuidv4().slice(0,12).toUpperCase()}`;
    let pendingTransaction;

    try {
        pendingTransaction = new Transaction({
            user: userId,
            type: 'deposit',
            amount: depositAmount,
            description: `Deposit Saldo (Pending) - ${payment_method}`,
            status: 'pending',
            paymentMethod: payment_method,
            midtransOrderId: transactionId
        });
        await pendingTransaction.save();

        if (payment_method === 'midtrans') {
            const parameter = {
                transaction_details: {
                    order_id: transactionId,
                    gross_amount: depositAmount
                },
                customer_details: {
                    first_name: userName,
                    email: userEmail,
                },
                item_details: [{
                    id: 'DEPOSIT01',
                    price: depositAmount,
                    quantity: 1,
                    name: 'Deposit Saldo SC Marketplace'
                }],
                callbacks: {
                    finish: `${req.protocol}://${req.get('host')}/dashboard/deposit/status?order_id=${transactionId}`
                }
            };

            const snapToken = await snapBalance.createTransactionToken(parameter);
            
            res.locals.midtransClientKey = MIDTRANS_CLIENT_KEY_BALANCE;
            res.locals.midtransIsProduction = MIDTRANS_IS_PRODUCTION_BALANCE;

            return res.render('balance/process_deposit', {
                titlePage: 'Proses Deposit',
                snapToken,
            });

        } else if (payment_method === 'qris_orkut') {
            const platformQrisBase = process.env.PLATFORM_QRIS_BASE_CODE || "YOUR_PLATFORM_QRIS_BASE_FALLBACK";
            if (!platformQrisBase || platformQrisBase === "YOUR_PLATFORM_QRIS_BASE_FALLBACK") {
                pendingTransaction.status = 'failed';
                pendingTransaction.description = 'Deposit Saldo (Failed) - Konfigurasi QRIS Platform tidak ada';
                await pendingTransaction.save();
                req.flash('error_msg', 'Metode pembayaran QRIS tidak tersedia saat ini (Platform).');
                return res.redirect('/dashboard/deposit');
            }
            const qrisData = await qrisHelper.createDynamicQRIS(depositAmount, platformQrisBase);

            pendingTransaction.midtransOrderId = qrisData.transactionId;
            pendingTransaction.description = `Deposit Saldo via QRIS (Pending) - ${qrisData.transactionId}`;
            await pendingTransaction.save();

            return res.render('payment/qris_display', {
                titlePage: 'Bayar Deposit dengan QRIS',
                qrisData,
                transactionType: 'deposit',
                checkStatusUrl: `/api/balance/deposit/qris/check-status`
            });
        } else {
            pendingTransaction.status = 'failed';
            pendingTransaction.description = 'Deposit Saldo (Failed) - Metode tidak valid';
            await pendingTransaction.save();
            req.flash('error_msg', 'Metode pembayaran tidak valid.');
            return res.redirect('/dashboard/deposit');
        }
    } catch (error) {
        if (pendingTransaction && pendingTransaction.status === 'pending') {
            pendingTransaction.status = 'failed';
            pendingTransaction.description = `Deposit Saldo (Failed) - ${error.message}`;
            await pendingTransaction.save().catch(e => console.error("Error saving failed transaction:", e));
        }
        req.flash('error_msg', `Gagal memproses deposit: ${error.message}`);
        res.redirect('/dashboard/deposit');
    }
};

exports.getDepositStatus = async (req, res) => {
    const { order_id, status_code, transaction_status } = req.query;
    let alertType = 'info';
    let message = 'Memproses status deposit Anda...';

    if (order_id === 'CLOSED') {
        alertType = 'warning';
        message = 'Anda menutup jendela pembayaran sebelum transaksi selesai.';
        return res.render('balance/deposit_status', { titlePage: 'Status Deposit', alertType, message, order_id });
    }
    
    if (!order_id) {
        req.flash('error_msg', 'ID Pesanan tidak ditemukan untuk status deposit.');
        return res.redirect('/dashboard/deposit');
    }

    try {
        const transaction = await Transaction.findOne({ midtransOrderId: order_id, user: req.user._id });

        if (!transaction) {
            message = `Transaksi dengan ID ${order_id} tidak ditemukan.`;
            alertType = 'danger';
        } else if (transaction.status === 'success') {
            message = `Deposit untuk ID ${order_id} sudah berhasil sebelumnya. Saldo Anda telah diperbarui.`;
            alertType = 'success';
        } else if (transaction_status) {
            if (transaction_status === 'capture' || transaction_status === 'settlement' || (transaction_status === 'success' && status_code === '200')) {
                 if (transaction.status !== 'success') {
                    transaction.status = 'success';
                    transaction.description = transaction.description.replace(/\(Pending\)/gi, '(Success)');
                    await transaction.save();
                    await User.findByIdAndUpdate(req.user._id, { $inc: { balance: transaction.amount } });
                    message = `Deposit sejumlah Rp ${transaction.amount.toLocaleString('id-ID')} untuk ID ${order_id} berhasil! Saldo telah ditambahkan.`;
                    alertType = 'success';
                }
            } else if (transaction_status === 'pending') {
                message = `Pembayaran untuk ID ${order_id} sedang diproses (pending). Harap tunggu konfirmasi.`;
                alertType = 'warning';
            } else if (['expire', 'cancel', 'deny'].includes(transaction_status) || (transaction_status === 'error' && status_code !== '200')) {
                transaction.status = 'failed';
                transaction.description = transaction.description.replace(/\(Pending\)/gi, `(Failed - ${transaction_status})`);
                await transaction.save();
                message = `Pembayaran untuk ID ${order_id} gagal atau dibatalkan. Status: ${transaction_status}.`;
                alertType = 'danger';
            } else {
                 message = `Status pembayaran untuk ID ${order_id} adalah ${transaction_status}.`;
                 alertType = 'info';
            }
        } else {
            message = `Status untuk transaksi ID ${order_id} adalah ${transaction.status}.`;
            if(transaction.status === 'success') alertType = 'success';
            else if (transaction.status === 'pending') alertType = 'warning';
            else alertType = 'danger';
        }
        res.render('balance/deposit_status', { titlePage: 'Status Deposit', alertType, message, order_id });
    } catch (error) {
        req.flash('error_msg', 'Terjadi kesalahan saat memeriksa status deposit.');
        res.redirect('/dashboard/deposit');
    }
};

exports.handleMidtransNotification = async (req, res) => {
    try {
        const notificationJson = req.body;
        const statusResponse = await snapBalance.transaction.notification(notificationJson);
        
        let orderId = statusResponse.order_id;
        let transactionStatus = statusResponse.transaction_status;
        let fraudStatus = statusResponse.fraud_status;
        let paymentType = statusResponse.payment_type || 'Midtrans';

        const transaction = await Transaction.findOne({ midtransOrderId: orderId });
        if (!transaction) {
            return res.status(404).send('Transaction not found');
        }
        
        if (transaction.status === 'pending') {
            if (transactionStatus == 'capture' || transactionStatus == 'settlement') {
                if (fraudStatus == 'accept') {
                    transaction.status = 'success';
                    transaction.description = transaction.description.replace(/\(Pending\)/gi, `(Success via ${paymentType})`);
                    if (transaction.type === 'deposit' && transaction.amount > 0) { // Hanya tambah saldo jika deposit
                        await User.findByIdAndUpdate(transaction.user, { $inc: { balance: transaction.amount } });
                    }
                } else if (fraudStatus == 'challenge') {
                    transaction.description = transaction.description.replace(/\(Pending\)/gi, `(Challenged by Fraud System via ${paymentType})`);
                }
            } else if (['cancel', 'deny', 'expire'].includes(transactionStatus)) {
                transaction.status = 'failed';
                transaction.description = transaction.description.replace(/\(Pending\)/gi, `(Failed via ${paymentType} - ${transactionStatus})`);
            } else if (transactionStatus == 'pending') {
                 transaction.description = transaction.description.replace(/\(Pending\)/gi, `(Still Pending via ${paymentType})`);
            }
            await transaction.save();
        }
        res.status(200).send('Notification processed.');
    } catch (error) {
        res.status(500).send('Error processing notification');
    }
};

exports.checkQrisDepositStatus = async (req, res) => {
    const { transactionId, orderId } = req.body;
    const qrisTxId = transactionId || orderId;

    if (!qrisTxId) {
        req.flash('error_msg', 'ID Transaksi QRIS tidak ada.');
        return res.redirect('back');
    }
    
    try {
        const transaction = await Transaction.findOne({ user: req.user._id, midtransOrderId: qrisTxId, type: 'deposit' });
        if (!transaction) {
            req.flash('error_msg', 'Transaksi deposit QRIS tidak ditemukan.');
            return res.redirect('/dashboard/deposit');
        }
        if (transaction.status === 'success') {
            req.flash('success_msg', 'Deposit QRIS Anda sudah berhasil sebelumnya.');
            return res.redirect('/dashboard/transactions');
        }

        const platformMerchantId = process.env.PLATFORM_OKECONNECT_MERCHANT_ID; // Asumsi ini masih dari .env atau hardcode lain
        const platformApiKey = process.env.PLATFORM_OKECONNECT_API_KEY; // Asumsi ini masih dari .env

        if (platformMerchantId && platformApiKey) {
            const statusResult = await qrisHelper.checkQRISPaymentStatus(platformMerchantId, platformApiKey);
            if (statusResult.success && Array.isArray(statusResult.data)) {
                const paidTx = statusResult.data.find(mutasi => 
                    parseInt(mutasi.amount) === transaction.amount &&
                    new Date(mutasi.date) > new Date(Date.now() - 30 * 60 * 1000)
                );

                if (paidTx) {
                    transaction.status = 'success';
                    transaction.description = transaction.description.replace(/\(Pending\)/gi, `(Success via QRIS - Okeconnect)`);
                    transaction.paymentMethod = transaction.paymentMethod + ` (${paidTx.brand_name || 'Okeconnect'})`
                    await transaction.save();
                    await User.findByIdAndUpdate(transaction.user, { $inc: { balance: transaction.amount } });
                    req.flash('success_msg', 'Pembayaran QRIS berhasil dikonfirmasi via Okeconnect! Saldo ditambahkan.');
                } else {
                    req.flash('info_msg', 'Status pembayaran QRIS belum terkonfirmasi di Okeconnect. Mohon tunggu atau coba lagi nanti.');
                }
            } else {
                req.flash('error_msg', `Gagal memeriksa status ke Okeconnect: ${statusResult.message || 'Data tidak diterima.'}`);
            }
        } else {
            req.flash('info_msg', 'Pengecekan status otomatis QRIS tidak tersedia. Admin akan memverifikasi manual.');
        }
        res.redirect('/dashboard/transactions');

    } catch (error) {
        req.flash('error_msg', 'Terjadi kesalahan saat memeriksa status deposit QRIS.');
        res.redirect('/dashboard/deposit');
    }
};