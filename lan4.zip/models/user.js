const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const userSchema = new mongoose.Schema({
    name: { type: String, required: true, trim: true },
    email: { type: String, required: true, unique: true, lowercase: true, trim: true },
    password: { type: String, required: true },
    role: { type: String, enum: ['customer', 'seller', 'admin'], default: 'customer' },
    balance: { type: Number, default: 0, min: 0 },
    
    profilePicture: { type: String, default: '/images/default-avatar.png' }, 
    storeName: { type: String, trim: true },
    bio: { type: String, trim: true, maxlength: 250 },
    location: { type: String, trim: true }, 
    website: { type: String, trim: true }, 
    qrisBaseCode: { type: String, trim: true },
    qrisMerchantId: { type: String, trim: true },
    qrisApiKey: { type: String, trim: true },
    
    createdAt: { type: Date, default: Date.now },
    updatedAt: { type: Date, default: Date.now }
});

userSchema.pre('save', async function(next) {
    if (this.isModified('password')) {
        this.password = await bcrypt.hash(this.password, 12);
    }
    if (!this.storeName && (this.role === 'seller' || this.role === 'admin')) {
        this.storeName = this.name;
    }
    this.updatedAt = Date.now();
    next();
});

userSchema.methods.comparePassword = async function(candidatePassword) {
    return bcrypt.compare(candidatePassword, this.password);
};

module.exports = mongoose.model('User', userSchema);