const Order = require('../models/order');
const SourceCode = require('../models/sourceCode');
const User = require('../models/user');
const Transaction = require('../models/transaction'); 
const midtransSnap = require('../config/midtrans'); 
module.exports.create_order_post = async (req, res) => {
  const { scId, orderType, rentalOptionIndex, payment_method } = req.body;
  const userId = req.user._id;

  if (!scId || !orderType || !payment_method) {
    req.flash('error_msg', 'Informasi pesanan tidak lengkap.');
    return res.redirect('back');
  }

  try {
    const sc = await SourceCode.findById(scId);
    if (!sc || sc.status !== 'approved') {
      req.flash('error_msg', 'Source code tidak ditemukan atau tidak tersedia.');
      return res.redirect('/sc-list');
    }

    const user = await User.findById(userId);
    if (!user) {
        req.flash('error_msg', 'Pengguna tidak ditemukan.');
        return res.redirect('/login');
    }

    let amount;
    let rentalDurationDays;
    let rentalEndDate;
    let orderDescription = '';

    if (orderType === 'buy') {
      if (sc.is_for_rent_only || !sc.price_buy) {
        req.flash('error_msg', 'Source code ini hanya untuk disewa.');
        return res.redirect(`/sc/${scId}`);
      }
      amount = sc.price_buy;
      orderDescription = `Pembelian SC: ${sc.title}`;
    } else if (orderType === 'rent') {
      if (!sc.rental_options || sc.rental_options.length === 0) {
        req.flash('error_msg', 'Source code ini tidak memiliki opsi sewa.');
        return res.redirect(`/sc/${scId}`);
      }
      const selectedOption = sc.rental_options[parseInt(rentalOptionIndex)];
      if (!selectedOption) {
        req.flash('error_msg', 'Opsi sewa tidak valid.');
        return res.redirect(`/sc/${scId}`);
      }
      amount = selectedOption.price;
      rentalDurationDays = selectedOption.durationDays;
      const startDate = new Date();
      rentalEndDate = new Date(new Date(startDate).setDate(startDate.getDate() + rentalDurationDays));
      orderDescription = `Sewa SC: ${sc.title} (${selectedOption.duration})`;
    } else {
      req.flash('error_msg', 'Tipe pesanan tidak valid.');
      return res.redirect('back');
    }

    if (payment_method === 'saldo') {
        if (user.balance < amount) {
            req.flash('error_msg', 'Saldo tidak mencukupi. Silakan deposit terlebih dahulu.');
            return res.redirect(`/sc/${scId}`);
        }

        const newOrder = new Order({
            user: userId,
            sourceCode: scId,
            orderType,
            rentalDurationDays: orderType === 'rent' ? rentalDurationDays : undefined,
            rentalEndDate: orderType === 'rent' ? rentalEndDate : undefined,
            amount,
            paymentStatus: 'completed',
            transactionId: `SALDO-${Date.now()}`
        });
        const savedOrder = await newOrder.save();

        user.balance -= amount;
        await user.save();

        await new Transaction({
            user: userId,
            type: orderType === 'buy' ? 'purchase_sc' : 'rent_sc',
            amount: -amount, // Pengurangan saldo
            description: orderDescription,
            paymentMethod: 'saldo',
            status: 'success',
            sourceCode: scId,
            relatedOrder: savedOrder._id
        }).save();

        req.flash('success_msg', `${orderDescription} berhasil menggunakan saldo.`);
        res.redirect('/dashboard/orders');

    } else if (payment_method === 'midtrans') {
        const midtransOrderId = `${orderType.toUpperCase()}-${userId}-${scId}-${Date.now()}`;
        const parameter = {
            transaction_details: {
                order_id: midtransOrderId,
                gross_amount: amount
            },
            customer_details: {
                first_name: user.name.split(' ')[0],
                last_name: user.name.split(' ').slice(1).join(' ') || user.name.split(' ')[0],
                email: user.email,
                phone: '081234567890'
            },
            item_details: [{
                id: scId,
                price: amount,
                quantity: 1,
                name: orderDescription.substring(0, 50) // Midtrans item name max 50 char
            }],
            callbacks: {
                finish: `${process.env.APP_BASE_URL}/dashboard/orders/status?order_id=${midtransOrderId}`
            }
        };

        const midtransTransactionResult = await midtransSnap.createTransaction(parameter);
        const snapToken = midtransTransactionResult.token;

        const newPendingOrder = new Order({ // Buat order dengan status pending dulu
            user: userId,
            sourceCode: scId,
            orderType,
            rentalDurationDays: orderType === 'rent' ? rentalDurationDays : undefined,
            rentalEndDate: orderType === 'rent' ? rentalEndDate : undefined,
            amount,
            paymentStatus: 'pending', // Status awal pending
            transactionId: midtransOrderId // Gunakan orderId Midtrans sebagai referensi
        });
        const savedPendingOrder = await newPendingOrder.save();

        await new Transaction({
            user: userId,
            type: orderType === 'buy' ? 'purchase_sc' : 'rent_sc',
            amount: amount, // Jumlah positif karena ini representasi tagihan
            description: orderDescription,
            midtransOrderId: midtransOrderId,
            paymentMethod: 'midtrans',
            status: 'pending',
            sourceCode: scId,
            relatedOrder: savedPendingOrder._id,
            metadata: { snapToken }
        }).save();

        res.render('balance/process_deposit', { // Re-use halaman proses deposit untuk SNAP
            titlePage: 'Proses Pembayaran',
            snapToken,
            clientKey: process.env.MIDTRANS_CLIENT_KEY,
            midtransIsProduction: process.env.MIDTRANS_IS_PRODUCTION === 'true'
        });

    } else {
        req.flash('error_msg', 'Metode pembayaran tidak valid.');
        return res.redirect('back');
    }

  } catch (err) {
    console.error(err);
    let errorMessage = 'Terjadi kesalahan saat memproses pesanan.';
    if (err.ApiResponse && err.ApiResponse.error_messages) {
        errorMessage = `Gagal memproses: ${err.ApiResponse.error_messages.join(', ')}`;
    } else if (err.message) {
        errorMessage = err.message;
    }
    req.flash('error_msg', errorMessage);
    res.redirect('back');
  }
};

module.exports.get_user_orders_status_page = async (req, res) => {
    // Mirip dengan get_deposit_status_page, tapi untuk order SC
    const { order_id } = req.query;
    let message = 'Memproses pembayaran Anda untuk pembelian/sewa SC...';
    let alertType = 'info';

    if (order_id) {
        const transaction = await Transaction.findOne({ midtransOrderId: order_id, user: req.user._id })
                                        .populate('relatedOrder');
        if (transaction && transaction.relatedOrder) {
            const order = transaction.relatedOrder;
            if (order.paymentStatus === 'completed') {
                message = `Pembayaran untuk Order ID: ${order_id} berhasil.`;
                alertType = 'success';
            } else if (order.paymentStatus === 'pending') {
                message = `Pembayaran untuk Order ID: ${order_id} masih menunggu konfirmasi.`;
                alertType = 'warning';
            } else if (['failed', 'cancelled', 'expired'].includes(order.paymentStatus) || ['failed', 'cancelled', 'expired'].includes(transaction.status)) {
                message = `Pembayaran untuk Order ID: ${order_id} gagal atau dibatalkan.`;
                alertType = 'danger';
            }
        } else {
            message = 'Transaksi pembelian/sewa tidak ditemukan.';
            alertType = 'danger';
        }
    } else {
        message = 'Tidak ada informasi transaksi.';
        alertType = 'warning';
    }
     res.render('user/order_status', { // Buat view order_status.ejs
        titlePage: 'Status Pembelian/Sewa SC',
        message,
        alertType,
        order_id
    });
};