const User = require('../models/user');
const Transaction = require('../models/transaction');
const midtransSnap = require('../config/midtrans');

module.exports.create_deposit_transaction = async (req, res) => {
    const { amount } = req.body;
    const userId = req.user._id;

    if (!amount || isNaN(parseFloat(amount)) || parseFloat(amount) <= 0) {
        req.flash('error_msg', 'Jumlah deposit tidak valid.');
        return res.redirect('/dashboard/deposit');
    }

    const depositAmount = parseFloat(amount);
    const orderId = `DEP-${userId}-${Date.now()}`;

    try {
        const user = await User.findById(userId);
        if (!user) {
            req.flash('error_msg', 'Pengguna tidak ditemukan.');
            return res.redirect('/login');
        }

        const parameter = {
            transaction_details: {
                order_id: orderId,
                gross_amount: depositAmount
            },
            customer_details: {
                first_name: user.name.split(' ')[0] || user.name,
                last_name: user.name.split(' ').slice(1).join(' ') || '',
                email: user.email,
                phone: '081234567890'
            },
            item_details: [{
                id: `deposit-${Date.now()}`,
                price: depositAmount,
                quantity: 1,
                name: "Deposit Saldo Akun"
            }],
            callbacks: {
                finish: `${process.env.APP_BASE_URL}/dashboard/deposit/status?order_id=${orderId}`
                // unfinish dan error bisa ditambahkan di sini jika diperlukan
                // unfinish: `${process.env.APP_BASE_URL}/dashboard/deposit/status?order_id=${orderId}&status=unfinish`,
                // error: `${process.env.APP_BASE_URL}/dashboard/deposit/status?order_id=${orderId}&status=error`
            }
            // Jika Anda ingin menggunakan expiry, pastikan koma setelah callbacks benar
            // , // Koma ini penting jika expiry diaktifkan
            // expiry: {
            //   start_time: new Date().toISOString().slice(0, 19) + "+07:00",
            //   unit: "minutes",
            //   duration: 60
            // }
        };

        const midtransTransaction = await midtransSnap.createTransaction(parameter);
        const snapToken = midtransTransaction.token;

        const newTransaction = new Transaction({
            user: userId,
            type: 'deposit',
            amount: depositAmount,
            description: `Deposit Saldo Rp ${depositAmount.toLocaleString('id-ID')}`,
            midtransOrderId: orderId,
            paymentMethod: 'midtrans',
            status: 'pending',
            metadata: { snapToken }
        });
        await newTransaction.save();

        res.render('balance/process_deposit', {
            titlePage: 'Proses Deposit',
            snapToken,
            clientKey: process.env.MIDTRANS_CLIENT_KEY,
            midtransIsProduction: process.env.MIDTRANS_IS_PRODUCTION === 'true'
        });

    } catch (error) {
        console.error('Midtrans create transaction error:', error);
        const errorMessage = (error.ApiResponse && error.ApiResponse.error_messages)
            ? error.ApiResponse.error_messages.join(', ')
            : (error.message || 'Kesalahan Internal Saat Membuat Transaksi Deposit');
        req.flash('error_msg', `Gagal membuat transaksi deposit: ${errorMessage}`);
        res.redirect('/dashboard/deposit');
    }
};

module.exports.get_deposit_status_page = async (req, res) => {
    const { order_id } = req.query;
    let message = 'Memproses pembayaran Anda...';
    let alertType = 'info';

    if (order_id && order_id !== 'CLOSED') {
        const transaction = await Transaction.findOne({ midtransOrderId: order_id, user: req.user._id });
        if (transaction) {
            if (transaction.status === 'success') {
                message = `Deposit untuk Order ID: ${order_id} berhasil. Saldo Anda telah diperbarui.`;
                alertType = 'success';
            } else if (transaction.status === 'pending') {
                message = `Pembayaran untuk Order ID: ${order_id} masih menunggu konfirmasi.`;
                alertType = 'warning';
            } else if (['failed', 'cancelled', 'expired'].includes(transaction.status)) {
                message = `Pembayaran untuk Order ID: ${order_id} gagal atau dibatalkan.`;
                alertType = 'danger';
            }
        } else {
            message = 'Transaksi deposit tidak ditemukan atau tidak sesuai.';
            alertType = 'danger';
        }
    } else if (order_id === 'CLOSED') {
        message = 'Anda menutup jendela pembayaran sebelum menyelesaikan transaksi.';
        alertType = 'warning';
    } else {
        message = 'Tidak ada informasi transaksi.';
        alertType = 'warning';
    }

    res.render('balance/deposit_status', {
        titlePage: 'Status Deposit',
        message,
        alertType,
        order_id
    });
};