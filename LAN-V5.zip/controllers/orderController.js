const Order = require('../models/order');
const SourceCode = require('../models/sourceCode');
const User =require('../models/user');
const Transaction = require('../models/transaction');
const midtransClient = require('midtrans-client');
const qrisHelper = require('../utils/qrisHelper');
const { v4: uuidv4 } = require('uuid');
const crypto = require('crypto');
const sellerController = require('./sellerController');
const mongoose = require('mongoose');

const MIDTRANS_SERVER_KEY_ORDER = process.env.MIDTRANS_SERVER_KEY || "Mid-server-zvgGUiY7SS-HS_qhWLkqZQuL";
const MIDTRANS_CLIENT_KEY_ORDER = process.env.MIDTRANS_CLIENT_KEY || "Mid-client-IoIOg2RqJNZgKpY6";
const MIDTRANS_IS_PRODUCTION_ORDER = process.env.MIDTRANS_IS_PRODUCTION === 'true' || false;

const snapOrder = new midtransClient.Snap({
    isProduction: MIDTRANS_IS_PRODUCTION_ORDER,
    serverKey: MIDTRANS_SERVER_KEY_ORDER,
    clientKey: MIDTRANS_CLIENT_KEY_ORDER
});

async function updateOrderAndTransactionStatus(order, transaction, status, paymentDetails = "") {
    let orderUpdated = false;
    let transactionUpdated = false;

    if (order && order.paymentStatus !== 'completed' && order.paymentStatus !== status) {
        order.paymentStatus = status;
        if (status === 'completed') {
            if (order.sourceCodeDetails && order.sourceCodeDetails.productType === 'source_code' && order.sourceCodeDetails.filePath && order.orderType === 'buy') {
                 order.downloadLink = `/${order.sourceCodeDetails.filePath.replace(/\\/g, '/')}`;
            } else if (order.sourceCodeDetails && order.sourceCodeDetails.productType === 'panel_service') {
                order.deliveryStatus = 'pending_provisioning';
            }
        }
        await order.save();
        orderUpdated = true;
    }
    
    if (transaction && transaction.status !== 'success' && transaction.status !== status) {
        let finalStatus = status;
        if (status === 'completed') finalStatus = 'success';
        
        transaction.status = finalStatus;
        let statusText = finalStatus.charAt(0).toUpperCase() + finalStatus.slice(1);
        if (paymentDetails) statusText += paymentDetails;
        transaction.description = transaction.description.replace(/\((Pending|Failed.*?)\)/gi, `(${statusText})`);
        await transaction.save();
        transactionUpdated = true;
    }
    return { orderUpdated, transactionUpdated };
}


exports.createOrder = async (req, res) => {
    const { scId, orderType, payment_method, rentalOptionIndex, panelUsername } = req.body;
    const userId = req.user.id;
    let newOrder, pendingScTransaction;

    try {
        const sc = await SourceCode.findById(scId).populate('seller', 'qrisBaseCode name email _id qrisMerchantId qrisApiKey pterodactylPanelUrl pterodactylAppApiKey pterodactylDefaultNestId pterodactylDefaultEggId pterodactylDefaultLocationId');
        if (!sc || sc.status !== 'approved') {
            req.flash('error_msg', 'Produk tidak valid atau tidak tersedia.');
            return res.redirect(scId ? `/sc/${scId}` : '/sc-list');
        }

        if (sc.productType === 'source_code' && orderType === 'buy') {
            const existingBuyOrder = await Order.findOne({ user: userId, sourceCode: scId, orderType: 'buy', paymentStatus: 'completed' });
            if (existingBuyOrder) {
                req.flash('info_msg', 'Anda sudah membeli source code ini.');
                return res.redirect(`/sc/${scId}`);
            }
        }

        let amount;
        let orderDetails = {
            user: userId,
            sourceCode: scId,
            scTitleAtPurchase: sc.title,
            sourceCodeDetails: {
                productType: sc.productType,
                seller: sc.seller._id,
                filePath: sc.filePath,
                panelRamMB: sc.panelRamMB,
                panelDiskMB: sc.panelDiskMB,
                panelCpuPercentage: sc.panelCpuPercentage
            },
            orderType,
            paymentMethod: payment_method,
            paymentStatus: 'pending',
            deliveryStatus: sc.productType === 'panel_service' ? 'pending_payment' : 'not_applicable'
        };
        let itemDisplayName = sc.productType === 'source_code' ? `Pembelian SC: ${sc.title}` : `Layanan Panel: ${sc.title}`;

        if (sc.productType === 'source_code') {
            if (orderType === 'buy') {
                if (sc.is_for_rent_only || sc.price_buy === null || sc.price_buy < 0) {
                    req.flash('error_msg', 'SC ini tidak tersedia untuk dibeli atau harga tidak valid.');
                    return res.redirect(`/sc/${scId}`);
                }
                amount = sc.price_buy;
            } else if (orderType === 'rent') {
                if (!sc.rental_options || sc.rental_options.length === 0) {
                    req.flash('error_msg', 'SC ini tidak tersedia untuk disewa.');
                    return res.redirect(`/sc/${scId}`);
                }
                const optionIdx = parseInt(rentalOptionIndex);
                if (isNaN(optionIdx) || optionIdx < 0 || optionIdx >= sc.rental_options.length || sc.rental_options[optionIdx].price < 0) {
                    req.flash('error_msg', 'Opsi sewa atau harga sewa tidak valid.');
                    return res.redirect(`/sc/${scId}`);
                }
                const selectedOption = sc.rental_options[optionIdx];
                amount = selectedOption.price;
                orderDetails.rentalOption = { duration: selectedOption.duration, price: selectedOption.price };
                let endDate = new Date();
                const [num, unit] = selectedOption.duration.split(' ');
                const numVal = parseInt(num);
                if (unit.toLowerCase().includes('minggu')) endDate.setDate(endDate.getDate() + (numVal * 7));
                else if (unit.toLowerCase().includes('bulan')) endDate.setMonth(endDate.getMonth() + numVal);
                else if (unit.toLowerCase().includes('tahun')) endDate.setFullYear(endDate.getFullYear() + numVal);
                orderDetails.rentalEndDate = endDate;
                itemDisplayName = `Sewa SC: ${sc.title} (${selectedOption.duration})`;
            } else {
                req.flash('error_msg', 'Tipe order tidak valid untuk source code.');
                return res.redirect(`/sc/${scId}`);
            }
        } else if (sc.productType === 'panel_service') {
            if (orderType !== 'buy') {
                req.flash('error_msg', 'Layanan panel hanya bisa dibeli.');
                return res.redirect(`/sc/${scId}`);
            }
            if (sc.price_buy === null || sc.price_buy < 0 || sc.price_buy > 100000) {
                 req.flash('error_msg', 'Harga layanan panel tidak valid.');
                return res.redirect(`/sc/${scId}`);
            }
            amount = sc.price_buy;
            orderDetails.panelUsernameChoice = panelUsername;
        } else {
            req.flash('error_msg', 'Tipe produk tidak dikenal.');
            return res.redirect(`/sc/${scId}`);
        }
        orderDetails.amount = amount;

        const orderTransactionId = `${sc.productType === 'panel_service' ? 'PNL' : 'ORD'}-${uuidv4().slice(0, 11).toUpperCase()}`;
        orderDetails.midtransOrderId = orderTransactionId;

        newOrder = new Order(orderDetails);
        await newOrder.save();

        pendingScTransaction = new Transaction({
            user: userId,
            type: sc.productType === 'panel_service' ? 'purchase_panel' : (orderType === 'buy' ? 'purchase_sc' : 'rent_sc'),
            amount: -amount,
            description: `${itemDisplayName} (Pending) - ${payment_method}`,
            status: 'pending',
            paymentMethod: payment_method,
            midtransOrderId: orderTransactionId,
            order: newOrder._id,
            sourceCode: scId
        });
        await pendingScTransaction.save();

        if (payment_method === 'saldo' || (payment_method === 'free' && amount === 0) ) {
            if (amount > 0 && req.user.balance < amount) {
                await updateOrderAndTransactionStatus(newOrder, pendingScTransaction, 'failed', 'Saldo Tidak Cukup');
                req.flash('error_msg', 'Saldo Anda tidak mencukupi untuk transaksi ini.');
                return res.redirect(`/sc/${scId}`);
            }
            if (amount > 0) {
                await User.findByIdAndUpdate(userId, { $inc: { balance: -amount } });
            }
            await updateOrderAndTransactionStatus(newOrder, pendingScTransaction, 'completed');

            if (sc.productType === 'panel_service') {
                const panelUser = panelUsername || req.user.name.toLowerCase().replace(/\s+/g, '') + Math.floor(Math.random() * 1000);
                const panelPass = crypto.randomBytes(10).toString('hex');
                
                const provisionResult = await sellerController.provisionPterodactylServer(newOrder, panelUser, panelPass);
                if (provisionResult.success) {
                    newOrder.panelDetails = { panelUrl: provisionResult.panelUrl, username: provisionResult.username, password: provisionResult.password, serverId: provisionResult.serverDetails.id, serverUuid: provisionResult.serverDetails.uuid };
                    newOrder.deliveryStatus = 'delivered';
                    await newOrder.save();
                    req.flash('success_msg', `${itemDisplayName} berhasil ${amount === 0 ? 'diambil' : 'dibayar'} & panel dibuat!`);
                    return res.redirect(`/sc/${scId}?provision=success&orderId=${newOrder._id}&panelUrl=${encodeURIComponent(provisionResult.panelUrl)}&username=${encodeURIComponent(provisionResult.username)}&password=${encodeURIComponent(provisionResult.password)}`);

                } else {
                    newOrder.deliveryStatus = 'provisioning_failed';
                    newOrder.notes = provisionResult.message;
                    await newOrder.save();
                    req.flash('error_msg', `Pembayaran berhasil, tapi gagal membuat panel: ${provisionResult.message}. Hubungi support.`);
                     return res.redirect(`/sc/${scId}?provision=failed&orderId=${newOrder._id}&message=${encodeURIComponent(provisionResult.message)}`);
                }
            } else {
                req.flash('success_msg', `${itemDisplayName} berhasil ${amount === 0 ? 'diambil' : 'dibayar dengan saldo'}.`);
            }
            return res.redirect(`/dashboard/orders`);

        } else if (payment_method === 'midtrans') {
            const parameter = {
                transaction_details: { order_id: orderTransactionId, gross_amount: amount },
                customer_details: { first_name: req.user.name, email: req.user.email },
                item_details: [{ id: scId.toString(), price: amount, quantity: 1, name: itemDisplayName }],
                callbacks: { finish: `${req.protocol}://${req.get('host')}/api/orders/status?order_id=${orderTransactionId}` }
            };
            const snapToken = await snapOrder.createTransactionToken(parameter);
            return res.render('balance/process_deposit', { titlePage: 'Proses Pembayaran Produk', snapToken });

        } else if (payment_method === 'qris_orkut') {
            if (!sc.seller || !sc.seller.qrisBaseCode) {
                await updateOrderAndTransactionStatus(newOrder, pendingScTransaction, 'failed', 'Seller QRIS Not Configured');
                req.flash('error_msg', 'Metode pembayaran QRIS tidak tersedia untuk seller ini.');
                return res.redirect(`/sc/${scId}`);
            }
            const qrisData = await qrisHelper.createDynamicQRIS(amount, sc.seller.qrisBaseCode, `Bayar ${itemDisplayName} ${orderTransactionId}`);
            
            newOrder.qrisData = { qrImageUrl: qrisData.qrImageUrl, qrString: qrisData.qrString, transactionId: qrisData.transactionId, sellerQrisUsed: true };
            if (newOrder.midtransOrderId !== qrisData.transactionId) {
                newOrder.midtransOrderId = qrisData.transactionId;
                pendingScTransaction.midtransOrderId = qrisData.transactionId;
                pendingScTransaction.description = pendingScTransaction.description.replace(orderTransactionId, qrisData.transactionId);
                await pendingScTransaction.save();
            }
            await newOrder.save();

            let checkStatusUrl = null;
            if (sc.seller.qrisMerchantId && sc.seller.qrisApiKey) {
                checkStatusUrl = `/api/orders/qris/check-status`;
            }
            return res.render('payment/qris_display', {
                titlePage: 'Bayar Pesanan dengan QRIS', qrisData, transactionType: 'order',
                scId: scId.toString(), orderId: newOrder._id.toString(),
                originalOrderId: newOrder.midtransOrderId,
                seller: { name: sc.seller.name, email: sc.seller.email }, checkStatusUrl
            });
        } else {
            await updateOrderAndTransactionStatus(newOrder, pendingScTransaction, 'failed', 'Invalid Payment Method');
            req.flash('error_msg', 'Metode pembayaran tidak valid.');
            return res.redirect(`/sc/${scId}`);
        }

    } catch (error) {
        console.error("Error in createOrder:", error);
        if (newOrder && pendingScTransaction && newOrder.paymentStatus === 'pending') {
            await updateOrderAndTransactionStatus(newOrder, pendingScTransaction, 'failed', 'System Error');
        } else if (newOrder && newOrder.paymentStatus === 'pending') {
             newOrder.paymentStatus = 'failed'; await newOrder.save().catch(e=>console.error(e));
        } else if (pendingScTransaction && pendingScTransaction.status === 'pending') {
             pendingScTransaction.status = 'failed'; await pendingScTransaction.save().catch(e=>console.error(e));
        }
        req.flash('error_msg', `Gagal membuat pesanan: ${error.message}`);
        return res.redirect(scId ? `/sc/${scId}` : '/sc-list');
    }
};

exports.getOrderStatusPage = async (req, res) => {
    const { order_id, status_code, transaction_status } = req.query;
    let alertType = 'info';
    let message = 'Memproses status pesanan Anda...';
    let orderForView = null;

    if (order_id === 'CLOSED') {
        alertType = 'warning';
        message = 'Anda menutup jendela pembayaran sebelum transaksi selesai.';
        return res.render('user/order_status', { titlePage: 'Status Pesanan', alertType, message, order_id });
    }
    if (!order_id) {
        req.flash('error_msg', 'ID Pesanan tidak ditemukan untuk status.');
        return res.redirect('/dashboard/orders');
    }

    try {
        const order = await Order.findOne({ midtransOrderId: order_id, user: req.user.id }).populate('user', 'name');
        const transaction = await Transaction.findOne({ midtransOrderId: order_id, user: req.user.id });
        orderForView = order;

        if (!order || !transaction) {
            message = `Pesanan/Transaksi dengan ID ${order_id} tidak ditemukan.`;
            alertType = 'danger';
        } else if (order.paymentStatus === 'completed') {
            message = `Pesanan untuk ID ${order_id} sudah berhasil sebelumnya.`;
            if (order.sourceCodeDetails && order.sourceCodeDetails.productType === 'panel_service' && order.deliveryStatus === 'delivered') {
                message += ` Layanan panel Anda sudah aktif. Cek detail pesanan.`;
            } else if (order.sourceCodeDetails && order.sourceCodeDetails.productType === 'panel_service' && order.deliveryStatus === 'pending_provisioning') {
                message += ` Layanan panel Anda sedang disiapkan.`;
            }
            alertType = 'success';
        } else if (transaction_status) {
            if (transaction_status === 'capture' || transaction_status === 'settlement' || (transaction_status === 'success' && status_code === '200')) {
                if (order.paymentStatus !== 'completed') {
                    await updateOrderAndTransactionStatus(order, transaction, 'completed');
                    message = `Pembayaran untuk pesanan ID ${order_id} berhasil!`;
                    alertType = 'success';

                    if (order.sourceCodeDetails && order.sourceCodeDetails.productType === 'panel_service') {
                        const panelUsername = order.panelUsernameChoice || order.user.name.toLowerCase().replace(/\s+/g, '') + Math.floor(Math.random() * 1000);
                        const panelPasswordGenerated = crypto.randomBytes(10).toString('hex');
                        const provisionResult = await sellerController.provisionPterodactylServer(order, panelUsername, panelPasswordGenerated);
                        if (provisionResult.success) {
                            order.panelDetails = { panelUrl: provisionResult.panelUrl, username: provisionResult.username, password: panelPasswordGenerated, serverId: provisionResult.serverDetails.id, serverUuid: provisionResult.serverDetails.uuid };
                            order.deliveryStatus = 'delivered';
                            await order.save();
                             message += ` Layanan panel Anda berhasil dibuat! Cek detail pesanan.`;
                        } else {
                            order.deliveryStatus = 'provisioning_failed';
                            order.notes = provisionResult.message;
                            await order.save();
                            message += ` Pembayaran berhasil, tapi gagal membuat panel: ${provisionResult.message}. Hubungi support.`;
                            alertType = 'warning';
                        }
                    }
                }
            } else if (transaction_status === 'pending') {
                message = `Pembayaran untuk pesanan ID ${order_id} sedang diproses (pending). Harap tunggu konfirmasi.`;
                alertType = 'warning';
            } else if (['expire', 'cancel', 'deny'].includes(transaction_status) || (transaction_status === 'error' && status_code !== '200')) {
                await updateOrderAndTransactionStatus(order, transaction, 'failed', transaction_status);
                message = `Pembayaran untuk pesanan ID ${order_id} gagal atau dibatalkan. Status: ${transaction_status}.`;
                alertType = 'danger';
            } else {
                message = `Status pembayaran untuk pesanan ID ${order_id} adalah ${transaction_status}.`;
                alertType = 'info';
            }
        } else {
            message = `Status untuk pesanan ID ${order_id} adalah ${order.paymentStatus}.`;
            if (order.paymentStatus === 'completed') alertType = 'success';
            else if (order.paymentStatus === 'pending') alertType = 'warning';
            else alertType = 'danger';
        }
        return res.render('user/order_status', { titlePage: 'Status Pesanan', alertType, message, order_id, order: orderForView });
    } catch (error) {
        console.error("Error in getOrderStatusPage:", error);
        req.flash('error_msg', 'Terjadi kesalahan saat memeriksa status pesanan.');
        return res.redirect('/dashboard/orders');
    }
};

exports.handleMidtransOrderNotification = async (req, res) => {
    try {
        const notificationJson = req.body;
        const statusResponse = await snapOrder.transaction.notification(notificationJson);
        
        let orderId = statusResponse.order_id;
        let transactionStatus = statusResponse.transaction_status;
        let fraudStatus = statusResponse.fraud_status;
        let paymentType = statusResponse.payment_type || 'Midtrans';

        const order = await Order.findOne({ midtransOrderId: orderId }).populate('user', 'name');
        const transaction = await Transaction.findOne({ midtransOrderId: orderId });

        if (!order || !transaction) {
            return res.status(404).send('Order/Transaction not found for notification');
        }
        
        if (order.paymentStatus === 'pending') {
            if (transactionStatus == 'capture' || transactionStatus == 'settlement') {
                if (fraudStatus == 'accept') {
                    await updateOrderAndTransactionStatus(order, transaction, 'completed', ` via ${paymentType}`);
                    if (order.sourceCodeDetails && order.sourceCodeDetails.productType === 'panel_service') {
                        const panelUsername = order.panelUsernameChoice || order.user.name.toLowerCase().replace(/\s+/g, '') + Math.floor(Math.random() * 1000);
                        const panelPasswordGenerated = crypto.randomBytes(10).toString('hex');
                        const provisionResult = await sellerController.provisionPterodactylServer(order, panelUsername, panelPasswordGenerated);
                        if (provisionResult.success) {
                            order.panelDetails = { panelUrl: provisionResult.panelUrl, username: provisionResult.username, password: panelPasswordGenerated, serverId: provisionResult.serverDetails.id, serverUuid: provisionResult.serverDetails.uuid };
                            order.deliveryStatus = 'delivered';
                        } else {
                            order.deliveryStatus = 'provisioning_failed';
                            order.notes = provisionResult.message;
                        }
                        await order.save();
                    }
                } else if (fraudStatus == 'challenge') {
                    transaction.description = transaction.description.replace(/\(Pending\)/gi, `(Challenged by Fraud System via ${paymentType})`);
                    await transaction.save();
                }
            } else if (['cancel', 'deny', 'expire'].includes(transactionStatus)) {
                await updateOrderAndTransactionStatus(order, transaction, 'failed', `${transactionStatus} via ${paymentType}`);
            } else if (transactionStatus == 'pending') {
                 transaction.description = transaction.description.replace(/\(Pending\)/gi, `(Still Pending via ${paymentType})`);
                 await transaction.save();
            }
        }
        return res.status(200).send('Notification processed.');
    } catch (error) {
        console.error("Error processing Midtrans order notification:", error);
        return res.status(500).send('Error processing order notification');
    }
};

exports.checkQrisOrderStatus = async (req, res) => {
    const { originalOrderId, orderId } = req.body;
    
    if (!orderId || !originalOrderId) {
        req.flash('error_msg', 'ID Pesanan atau ID Transaksi QRIS tidak valid.');
        return res.redirect('back');
    }

    try {
        const order = await Order.findById(orderId).populate('user', 'name');
        if (!order || order.user._id.toString() !== req.user.id.toString()) {
            req.flash('error_msg', 'Pesanan tidak ditemukan atau bukan milik Anda.');
            return res.redirect('/dashboard/orders');
        }
        if (order.paymentStatus === 'completed') {
            req.flash('success_msg', 'Pesanan ini sudah berhasil dibayar sebelumnya.');
            return res.redirect('/dashboard/orders');
        }
        if (!order.qrisData || order.midtransOrderId !== originalOrderId) {
            req.flash('error_msg', 'Data QRIS untuk pesanan ini tidak cocok dengan ID transaksi yang dicek.');
            return res.redirect('/dashboard/orders');
        }

        const seller = await User.findById(order.sourceCodeDetails.seller); // Ambil seller dari sourceCodeDetails
        if (!seller || !seller.qrisMerchantId || !seller.qrisApiKey) {
            req.flash('info_msg', 'Pengecekan status otomatis QRIS tidak tersedia untuk seller ini. Seller akan memverifikasi manual.');
            return res.redirect('/dashboard/orders');
        }

        const statusResult = await qrisHelper.checkQRISPaymentStatus(seller.qrisMerchantId, seller.qrisApiKey);
        if (statusResult.success && Array.isArray(statusResult.data)) {
             const tenMinutesAgo = new Date(order.createdAt.getTime() - 10 * 60 * 1000);
             const tenMinutesAfter = new Date(Date.now() + 10 * 60 * 1000);

            const paidTx = statusResult.data.find(mutasi => 
                parseInt(mutasi.amount) === order.amount &&
                new Date(mutasi.date) >= tenMinutesAgo &&
                new Date(mutasi.date) <= tenMinutesAfter &&
                ( (mutasi.notes && mutasi.notes.includes(originalOrderId)) || mutasi.reff_id === originalOrderId )
            );

            if (paidTx) {
                const transaction = await Transaction.findOne({ order: order._id, midtransOrderId: originalOrderId });
                if (transaction && transaction.status !== 'success') {
                    await updateOrderAndTransactionStatus(order, transaction, 'completed', ` via QRIS Seller (Okeconnect - ${paidTx.brand_name || 'Unknown'})`);
                     if (order.sourceCodeDetails && order.sourceCodeDetails.productType === 'panel_service') {
                        const panelUsername = order.panelUsernameChoice || order.user.name.toLowerCase().replace(/\s+/g, '') + Math.floor(Math.random() * 1000);
                        const panelPasswordGenerated = crypto.randomBytes(10).toString('hex');
                        const provisionResult = await sellerController.provisionPterodactylServer(order, panelUsername, panelPasswordGenerated);
                        if (provisionResult.success) {
                            order.panelDetails = { panelUrl: provisionResult.panelUrl, username: provisionResult.username, password: panelPasswordGenerated, serverId: provisionResult.serverDetails.id, serverUuid: provisionResult.serverDetails.uuid };
                            order.deliveryStatus = 'delivered';
                            await order.save();
                             req.flash('success_msg', 'Pembayaran QRIS berhasil & panel dibuat! Cek detail pesanan.');
                        } else {
                            order.deliveryStatus = 'provisioning_failed';
                            order.notes = provisionResult.message;
                            await order.save();
                             req.flash('error_msg', `Pembayaran QRIS berhasil, tapi gagal membuat panel: ${provisionResult.message}. Hubungi support.`);
                        }
                    } else {
                        req.flash('success_msg', 'Pembayaran QRIS berhasil dikonfirmasi via Okeconnect!');
                    }
                } else if (!transaction) {
                    req.flash('error_msg', 'Transaksi terkait tidak ditemukan untuk pembaruan status QRIS.');
                } else {
                     req.flash('success_msg', 'Pembayaran QRIS sudah terkonfirmasi sebelumnya.');
                }
            } else {
                req.flash('info_msg', 'Status pembayaran QRIS belum terkonfirmasi di Okeconnect. Mohon tunggu atau seller akan verifikasi.');
            }
        } else {
            req.flash('error_msg', `Gagal memeriksa status ke Okeconnect: ${statusResult.message || 'Data tidak diterima.'}`);
        }
        return res.redirect('/dashboard/orders');
    } catch (error) {
        console.error("Error in checkQrisOrderStatus:", error);
        req.flash('error_msg', 'Terjadi kesalahan saat memeriksa status pesanan QRIS.');
        return res.redirect('/dashboard/orders');
    }
};