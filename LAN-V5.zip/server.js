require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const session = require('express-session');
const flash = require('connect-flash');
const expressLayouts = require('express-ejs-layouts');
const cookieParser = require('cookie-parser');
const methodOverride = require('method-override');
const path = require('path');
const http = require('http');
const { Server } = require("socket.io");
const User = require('./models/user');
const Ticket = require('./models/ticket');
const jwt = require('jsonwebtoken');
const { checkUserOptional } = require('./middleware/authMiddleware');

const MY_MIDTRANS_SERVER_KEY = process.env.MIDTRANS_SERVER_KEY || "Mid-server-zvgGUiY7SS-HS_qhWLkqZQuL";
const MY_MIDTRANS_CLIENT_KEY = process.env.MIDTRANS_CLIENT_KEY || "Mid-client-IoIOg2RqJNZgKpY6";
const MY_MIDTRANS_IS_PRODUCTION = process.env.MIDTRANS_IS_PRODUCTION === 'true' || false;

const app = express();
const server = http.createServer(app);
const io = new Server(server);

mongoose.connect(process.env.MONGO_URI || "mongodb://localhost:27017/sc_marketplace_prod", { useNewUrlParser: true, useUnifiedTopology: true })
    .then(() => console.log('MongoDB Connected...'))
    .catch(err => console.error('MongoDB Connection Error:', err));

app.use(expressLayouts);
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.set('layout', 'layouts/main');

app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(cookieParser());

const sessionMiddleware = session({
    secret: process.env.SESSION_SECRET || "your_very_strong_session_secret_key_12345",
    resave: false,
    saveUninitialized: true,
    cookie: { maxAge: 7 * 24 * 60 * 60 * 1000 }
});
app.use(sessionMiddleware);

app.use(methodOverride('_method'));
app.use(flash());

app.use((req, res, next) => {
    res.locals.success_msg = req.flash('success_msg');
    res.locals.error_msg = req.flash('error_msg');
    res.locals.error = req.flash('error');
    res.locals.errors = req.flash('errors');
    res.locals.formInput = req.flash('formInput')[0];
    res.locals.titlePage = "SC Marketplace";
    res.locals.midtransClientKey = MY_MIDTRANS_CLIENT_KEY;
    res.locals.midtransIsProduction = MY_MIDTRANS_IS_PRODUCTION;
    next();
});

app.use(checkUserOptional);

app.use(express.static(path.join(__dirname, 'public')));
app.use('/uploads', express.static(path.join(__dirname, 'public', 'uploads')));

const indexRoutes = require('./routes/indexRoutes');
const authRoutes = require('./routes/authRoutes');
const scRoutes = require('./routes/scRoutes');
const orderRoutes = require('./routes/orderRoutes');
const balanceRoutes = require('./routes/balanceRoutes');
const userRoutes = require('./routes/userRoutes');
const adminRoutes = require('./routes/adminRoutes');
const ticketRoutes = require('./routes/ticketRoutes');
const sellerRoutes = require('./routes/sellerRoutes'); 
const openApiRoutes = require('./routes/openApiRoutes');

app.use('/', indexRoutes);
app.use('/', authRoutes);
app.use('/', balanceRoutes);
app.use('/', userRoutes);
app.use('/', scRoutes);
app.use('/', openApiRoutes);
app.use('/', sellerRoutes); // Ditambahkan
app.use('/api/orders', orderRoutes);
app.use('/admin', adminRoutes);
app.use('/api/tickets', ticketRoutes);

io.use((socket, next) => {
    sessionMiddleware(socket.request, socket.request.res || {}, next);
});

io.on('connection', (socket) => {
    console.log('A user connected to Socket.IO:', socket.id);
    const session = socket.request.session;
    let userId = null;
    let userName = 'Guest';
    let userRole = 'guest';

    if (session && session.userId) {
        userId = session.userId;
        userName = session.userName || 'User';
        userRole = session.role || 'customer';
        socket.join(userId.toString());
    } else {
        const tokenFromHeader = socket.handshake.headers.cookie ? socket.handshake.headers.cookie.split('; ').find(row => row.startsWith('token='))?.split('=')[1] : null;
        const token = socket.handshake.auth.token || tokenFromHeader;
        if (token) {
            try {
                const decoded = jwt.verify(token, process.env.JWT_SECRET);
                userId = decoded.id;
                userName = decoded.name;
                userRole = decoded.role;
                if(session){
                    session.userId = userId;
                    session.userName = userName;
                    session.role = userRole;
                }
                socket.join(userId.toString());
                 console.log(`Socket.IO: User ${userName} (${userId}) authenticated via token.`);
            } catch (err) {
                console.log('Socket.IO: Invalid token, user remains guest.', err.message);
            }
        }
    }

    if (!userId) {
        console.log('Socket.IO: User not authenticated, some features might be limited for guest:', socket.id);
    }

    socket.on('joinTicketRoom', (ticketId) => {
        if (ticketId && userId) {
            socket.join(ticketId.toString());
            console.log(`User ${userName} (${userId}) joined ticket room: ${ticketId}`);
        } else if (!userId) {
            socket.emit('socketError', { message: 'Autentikasi diperlukan untuk bergabung ke room tiket.' });
        }
    });

    socket.on('leaveTicketRoom', (ticketId) => {
        if (ticketId && userId) {
            socket.leave(ticketId.toString());
            console.log(`User ${userName} (${userId}) left ticket room: ${ticketId}`);
        }
    });

    socket.on('newTicketMessage', async (data) => {
        if (!userId) {
            socket.emit('socketError', { message: 'Anda harus login untuk mengirim pesan.' });
            return;
        }
        if (!data.ticketId || !data.message) {
            socket.emit('socketError', { message: 'Data tidak lengkap untuk pesan baru.' });
            return;
        }

        try {
            const ticket = await Ticket.findById(data.ticketId)
                .populate('user', '_id name')
                .populate('assignedTo', '_id name');

            if (!ticket) {
                socket.emit('socketError', { message: 'Tiket tidak ditemukan.' });
                return;
            }

            const isOwner = ticket.user._id.toString() === userId;
            const isAdmin = userRole === 'admin';
            const isAssignedTo = ticket.assignedTo && ticket.assignedTo._id.toString() === userId;

            if (!isOwner && !isAdmin && !isAssignedTo) {
                socket.emit('socketError', { message: 'Anda tidak berhak mengirim pesan ke tiket ini.' });
                return;
            }
             if (ticket.status === 'closed' || ticket.status === 'resolved') {
                socket.emit('socketError', { message: 'Tiket sudah ditutup/selesai, tidak bisa mengirim pesan.' });
                return;
            }

            const senderDetails = await User.findById(userId).select('name role profilePicture');
            if (!senderDetails) {
                 socket.emit('socketError', { message: 'Pengirim tidak ditemukan.' });
                return;
            }

            const newMessage = {
                sender: userId,
                message: data.message.trim(),
                createdAt: new Date()
            };
            ticket.messages.push(newMessage);

            if (isOwner) {
                ticket.status = ticket.assignedTo ? 'pending_reply' : 'open';
            } else {
                ticket.status = 'open';
            }
            ticket.updatedAt = Date.now();
            await ticket.save();

            const messageToSend = {
                ...newMessage,
                sender: {
                    _id: senderDetails._id,
                    name: senderDetails.name,
                    role: senderDetails.role,
                    profilePicture: senderDetails.profilePicture
                },
                ticketId: ticket._id.toString()
            };

            io.to(ticket._id.toString()).emit('receiveTicketMessage', messageToSend);

            if (isOwner && ticket.assignedTo) {
                io.to(ticket.assignedTo._id.toString()).emit('newNotification', {
                    message: `Pesan baru di tiket #${ticket._id.toString().slice(-6)} dari ${senderDetails.name}`,
                    link: `/api/tickets/admin/view/${ticket._id}`
                });
            } else if (!isOwner && ticket.user) {
                 io.to(ticket.user._id.toString()).emit('newNotification', {
                    message: `Balasan baru di tiket #${ticket._id.toString().slice(-6)} dari ${senderDetails.name}`,
                    link: `/api/tickets/${ticket._id}`
                });
            }
        } catch (error) {
            console.error('Error handling newTicketMessage:', error);
            socket.emit('socketError', { message: 'Gagal mengirim pesan: ' + error.message });
        }
    });

    socket.on('typing', (data) => {
        if (data.ticketId && data.isTyping && userId) {
            socket.to(data.ticketId.toString()).emit('userTyping', { userId, ticketId: data.ticketId, userName: userName });
        }
    });

    socket.on('stopTyping', (data) => {
         if (data.ticketId && userId) {
            socket.to(data.ticketId.toString()).emit('userStopTyping', { userId, ticketId: data.ticketId });
        }
    });

    socket.on('disconnect', () => {
        console.log('User disconnected from Socket.IO:', socket.id);
    });
});

app.use((req, res, next) => {
    const err = new Error('Halaman Tidak Ditemukan');
    err.status = 404;
    next(err);
});

app.use((err, req, res, next) => {
    const status = err.status || 500;
    const titlePage = status === 404 ? "404 Tidak Ditemukan" : "Kesalahan Server";
    const viewToRender = status === 404 ? 'pages/404' : 'pages/500';

    if (res.headersSent) {
      return next(err);
    }
    console.error("Final Error Handler:", err.message, err.stack ? err.stack.substring(0, 500) : "No stack");

    res.status(status).render(viewToRender, {
        titlePage,
        error: (process.env.NODE_ENV !== 'production' || !MY_MIDTRANS_IS_PRODUCTION) ? err.message : "Terjadi kesalahan pada server.",
        stack: (process.env.NODE_ENV !== 'production' || !MY_MIDTRANS_IS_PRODUCTION) ? err.stack : ""
    });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => console.log(`Server running with Socket.IO on port ${PORT}`));