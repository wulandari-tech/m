# wanzz
# farm-api
# wanzz
# farm-api
# wanzz
# wanzz git init git add README.md git commit -m first commit git branch -M main git remote add origin https://github.com/wulandari-tech/wanzz.git git push -u origin main
# wanzz git init git add README.md git commit -m first commit git branch -M main git remote add origin https://github.com/wulandari-tech/wanzz.git git push -u origin main
# wanzz
# wanzz
# wanzz git init git add README.md git commit -m first commit git branch -M main git remote add origin https://github.com/wulandari-tech/wanzz.git git push -u origin main
# wanzz git init git add README.md git commit -m first commit git branch -M main git remote add origin https://github.com/wulandari-tech/wanzz.git git push -u origin main
# farm-api
# storee
# storee
# storee
# storee
# landarii
# landarii
